#include <string_view>
#include <map>
#include <cassert>
#include <stdexcept>
#include <utility>
#include <vector>
#include <variant>

/* Parsing and evaluating simple expressions, 10 points. */

/* A type which represents parsed expressions. The representation
 * and interface is entirely up to you. An expression is a sum
 * (additions and subtractions) of clauses where each clause is a
 * product (multiplication) of at most a single constant and some
 * (zero or more) variables. */

using values_t = std::map<char, int>;

struct clause {
    const int constant = 1;
    std::string variables;

    clause(const int c, std::string v) : constant(c), variables(std::move(v)) {};

    int eval(const values_t &v) {
        int result = constant;
        for (auto c : variables) {
            if (v.find(c) == v.end()) {
                throw std::out_of_range("dafsdfasdf");
            }
            result *= v.at(c);
        }
        return result;
    }
};

enum class op {
    ADD, SUB, NONE
};


int add(op operand, int left, clause right, const values_t &v) {
    switch (operand) {
        case op::ADD:
            return left + right.eval(v);
        case op::SUB:
            return left - right.eval(v);
        case op::NONE:
            break;
    }
    return 0;
}

struct expr {
    std::vector<std::pair<clause, op>> ex;

    explicit expr(std::vector<std::pair<clause, op>> e) : ex(std::move(e)) {};

    int eval(const values_t &v) const {
        int result = 0;
        op prev_op = op::ADD;
        for (auto &[c, o] : ex) {
            if (o == op::NONE) {
                return add(prev_op, result, c, v);
            }
            result = add(prev_op, result, c, v);
            prev_op = o;
        }
        return result;
    }
};

struct parse_error : std::exception {
};

/* Write a simple expression parser; the input expressions have the
 * following format:
 *
 *     expr     = clause | clause, op, expr ;
 *     clause   = ( constant | variable ), { variable } ;
 *     op       = space, ( '+' | '-' ), space ;
 *     variable = ? a single letter (std::isalpha) ? ;
 *     constant = ? a single digit (std::isdigit) ? ;
 *     space    = ? zero or more spaces (std::isspace) ? ;
 *
 * If the input string does not «exactly» conform to the grammar,
 * ‹parse› «must» throw a ‹parse_error›. */

enum class expected {
    CLAUSE, OPERAND
};

void parse_lexeme(std::string lexeme, std::vector<std::pair<clause, op>> &parsed_expr, expected &flag) {
    try {
        int constant = 1;
        if (flag == expected::CLAUSE) {
            if (std::isdigit(lexeme[0])) {
                constant = lexeme[0] - '0';
                lexeme.erase(lexeme.begin());
            }
            for (char c : lexeme) {
                if (!std::isalpha(c)) {
                    throw parse_error();
                }
            }
            parsed_expr.emplace_back(std::pair<clause, op>(clause(constant, lexeme), op::NONE));
            flag = expected::OPERAND;
            return;
        } else {
            if (lexeme.size() == 1) {
                if (lexeme[0] == '+') {
                    parsed_expr.back().second = op::ADD;
                    flag = expected::CLAUSE;
                    return;
                }
                if (lexeme[0] == '-') {
                    parsed_expr.back().second = op::SUB;
                    flag = expected::CLAUSE;
                    return;
                }
            }
            throw parse_error();
        }
    } catch (...) {
        throw;
    }
}

expr parse(std::string_view input) {
    if (std::isspace(input[0]) || std::isspace(input.back())) {
        throw parse_error();
    }
    try {
        std::string lexeme;
        expected flag = expected::CLAUSE;
        std::vector<std::pair<clause, op>> parsed_expr;
        for (char c : input) {
            if (std::isspace(c) && !lexeme.empty()) {
                parse_lexeme(lexeme, parsed_expr, flag);
                lexeme = "";
                continue;
            }
            if (!std::isspace(c)) {
                lexeme += c;
            }
        }
        if (!lexeme.empty()) {
            parse_lexeme(lexeme, parsed_expr, flag);
            lexeme = "";
        }
    } catch (...) {
        throw;
    }
}

/* Evaluate a parsed expression. The second argument gives a value
 * to each variable. Throw ‹std::out_of_range› if the expression
 * contains a variable not present in the map. */


int eval(const expr &ex, const values_t &v) {
    return ex.eval(v);
}

/* What follows are «basic» test cases for your convenience. You can
 * add additional test cases into main(): they «will not» be
 * executed during evaluation, so it is okay to submit with broken
 * main. However, make sure to «not» alter the line with the
 * prototype. */

int main() {
    auto check_throws = [](std::string_view s) {
        try {
            parse(s);
            assert(false);
        }
        catch (const parse_error &) {}
    };

    auto pe = [](std::string_view s, values_t v) {
        expr e = parse(s);
        return eval(e, v);
    };

    check_throws("11");
    check_throws(" 1");
    check_throws("x1");
    check_throws("1 + 11");
    check_throws("1 * 1");

    assert(pe("1", {}) == 1);
    assert(pe("1 + 1", {}) == 2);
    assert(pe("1 - 1", {}) == 0);
    assert(pe("x", {{'x', 1}}) == 1);
    assert(pe("xx + 2xy + yy", {{'x', 1},
                                {'y', 0}}) == 1);

    try {
        pe("xy", {{'x', 1}});
        assert(false);
    }
    catch (const std::out_of_range &) {}

    return 0;
}
